package com.example.mynotes

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

const val PW = 800f
val COVERS = listOf(0xFF4F46E5L, 0xFF0F766E, 0xFFB4234AL, 0xFF9A5B00L, 0xFF334155L, 0xFF6D28D9L)
val PAPERS = listOf("blank", "lined", "grid", "dotted", "infinite")

data class Pt(val x: Float, val y: Float, val p: Float)

sealed class El { abstract val id: Long }
data class StrokeEl(override val id: Long, val tool: Char, val color: Long, val width: Float, val pts: List<Pt>) : El()
data class ShapeEl(override val id: Long, val kind: Char, val color: Long, val width: Float, val x1: Float, val y1: Float, val x2: Float, val y2: Float) : El()
data class TextEl(override val id: Long, val text: String, val x: Float, val y: Float, val size: Float, val color: Long) : El()
data class ImageEl(override val id: Long, val file: String, val x: Float, val y: Float, val w: Float, val h: Float) : El()

class PageData(var els: List<El> = emptyList(), paper0: String = "", var h: Float = 1100f, var pdfPage: Int = -1) {
    var paper: String by mutableStateOf(paper0)
}

class Notebook(
    val id: String,
    var title: String,
    val color: Long,
    var paper: String,
    val pages: MutableList<PageData>,
    var updated: Long,
    var folder: String = "",
    var fav: Boolean = false,
    var trash: Boolean = false,
    val pdf: String = ""
)

class LibData(val books: MutableList<Notebook>, val folders: MutableList<String>)

object Ids {
    private var n = System.currentTimeMillis() * 1000
    fun next(): Long = n++
}

fun PageData.paperOf(nb: Notebook) = if (paper.isEmpty()) nb.paper else paper

object Store {
    private fun encEl(e: El): JSONObject = when (e) {
        is StrokeEl -> JSONObject().put("k", "s").put("id", e.id).put("t", e.tool.toString()).put("c", e.color)
            .put("w", e.width.toDouble())
            .put("p", JSONArray().also { a -> e.pts.forEach { a.put(it.x.toDouble()); a.put(it.y.toDouble()); a.put(it.p.toDouble()) } })
        is ShapeEl -> JSONObject().put("k", "h").put("id", e.id).put("t", e.kind.toString()).put("c", e.color)
            .put("w", e.width.toDouble())
            .put("a", JSONArray(listOf(e.x1.toDouble(), e.y1.toDouble(), e.x2.toDouble(), e.y2.toDouble())))
        is TextEl -> JSONObject().put("k", "x").put("id", e.id).put("s", e.text).put("x", e.x.toDouble())
            .put("y", e.y.toDouble()).put("z", e.size.toDouble()).put("c", e.color)
        is ImageEl -> JSONObject().put("k", "i").put("id", e.id).put("f", e.file).put("x", e.x.toDouble())
            .put("y", e.y.toDouble()).put("w", e.w.toDouble()).put("h", e.h.toDouble())
    }

    private fun decEl(o: JSONObject): El? = try {
        when (o.getString("k")) {
            "s" -> {
                val a = o.getJSONArray("p")
                val pts = ArrayList<Pt>()
                var m = 0
                while (m + 2 < a.length()) {
                    pts.add(Pt(a.getDouble(m).toFloat(), a.getDouble(m + 1).toFloat(), a.getDouble(m + 2).toFloat()))
                    m += 3
                }
                StrokeEl(o.getLong("id"), o.getString("t")[0], o.getLong("c"), o.getDouble("w").toFloat(), pts)
            }
            "h" -> {
                val a = o.getJSONArray("a")
                ShapeEl(o.getLong("id"), o.getString("t")[0], o.getLong("c"), o.getDouble("w").toFloat(),
                    a.getDouble(0).toFloat(), a.getDouble(1).toFloat(), a.getDouble(2).toFloat(), a.getDouble(3).toFloat())
            }
            "x" -> TextEl(o.getLong("id"), o.getString("s"), o.getDouble("x").toFloat(), o.getDouble("y").toFloat(),
                o.getDouble("z").toFloat(), o.getLong("c"))
            "i" -> ImageEl(o.getLong("id"), o.getString("f"), o.getDouble("x").toFloat(), o.getDouble("y").toFloat(),
                o.getDouble("w").toFloat(), o.getDouble("h").toFloat())
            else -> null
        }
    } catch (e: Exception) {
        null
    }

    fun encode(books: List<Notebook>, folders: List<String>): String {
        val root = JSONObject()
        root.put("folders", JSONArray(folders))
        val ba = JSONArray()
        for (n in books) {
            val o = JSONObject().put("id", n.id).put("title", n.title).put("color", n.color).put("paper", n.paper)
                .put("updated", n.updated).put("folder", n.folder).put("fav", n.fav).put("trash", n.trash).put("pdf", n.pdf)
            val pa = JSONArray()
            for (pg in n.pages) {
                val ea = JSONArray()
                pg.els.forEach { ea.put(encEl(it)) }
                pa.put(JSONObject().put("els", ea).put("paper", pg.paper).put("h", pg.h.toDouble()).put("pdf", pg.pdfPage))
            }
            o.put("pages", pa)
            ba.put(o)
        }
        root.put("books", ba)
        return root.toString()
    }

    private fun decBook(o: JSONObject): Notebook {
        val pa = o.getJSONArray("pages")
        val pages = (0 until pa.length()).map { j ->
            val po = pa.getJSONObject(j)
            val ea = po.getJSONArray("els")
            PageData((0 until ea.length()).mapNotNull { decEl(ea.getJSONObject(it)) }, po.optString("paper", ""),
                po.optDouble("h", 1100.0).toFloat(), po.optInt("pdf", -1))
        }.toMutableList()
        if (pages.isEmpty()) pages.add(PageData())
        return Notebook(o.getString("id"), o.getString("title"), o.getLong("color"), o.getString("paper"), pages,
            o.getLong("updated"), o.optString("folder", ""), o.optBoolean("fav"), o.optBoolean("trash"), o.optString("pdf", ""))
    }

    fun decode(text: String): LibData {
        val root = JSONObject(text)
        val fo = root.optJSONArray("folders") ?: JSONArray()
        val folders = (0 until fo.length()).map { fo.getString(it) }.toMutableList()
        val ba = root.getJSONArray("books")
        val books = (0 until ba.length()).map { decBook(ba.getJSONObject(it)) }.toMutableList()
        return LibData(books, folders)
    }

    fun load(c: Context): LibData {
        val f = File(c.filesDir, "library.json")
        return try {
            if (f.exists()) decode(f.readText()) else LibData(mutableListOf(), mutableListOf())
        } catch (e: Exception) {
            LibData(mutableListOf(), mutableListOf())
        }
    }

    fun write(c: Context, json: String) {
        val tmp = File(c.filesDir, "library.tmp")
        tmp.writeText(json)
        tmp.renameTo(File(c.filesDir, "library.json"))
    }
}
