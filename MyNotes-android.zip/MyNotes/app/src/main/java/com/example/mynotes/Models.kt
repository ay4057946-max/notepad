package com.example.mynotes

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Pt(val x: Float, val y: Float, val p: Float)
data class InkStroke(val tool: Char, val color: Long, val width: Float, val pts: List<Pt>)
class PageData(var strokes: List<InkStroke> = emptyList())
class Notebook(
    val id: String,
    var title: String,
    val color: Long,
    val paper: String,
    val pages: MutableList<PageData>,
    var updated: Long
)

object Store {
    private fun file(c: Context) = File(c.filesDir, "notebooks.json")

    fun load(c: Context): MutableList<Notebook> {
        val f = file(c)
        if (!f.exists()) return mutableListOf()
        return try {
            val arr = JSONArray(f.readText())
            val out = mutableListOf<Notebook>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val pages = mutableListOf<PageData>()
                val pa = o.getJSONArray("pages")
                for (j in 0 until pa.length()) {
                    val sa = pa.getJSONArray(j)
                    val ss = mutableListOf<InkStroke>()
                    for (k in 0 until sa.length()) {
                        val so = sa.getJSONObject(k)
                        val fl = so.getJSONArray("p")
                        val pts = ArrayList<Pt>()
                        var m = 0
                        while (m + 2 < fl.length()) {
                            pts.add(Pt(fl.getDouble(m).toFloat(), fl.getDouble(m + 1).toFloat(), fl.getDouble(m + 2).toFloat()))
                            m += 3
                        }
                        ss.add(InkStroke(so.getString("t")[0], so.getLong("c"), so.getDouble("w").toFloat(), pts))
                    }
                    pages.add(PageData(ss))
                }
                if (pages.isEmpty()) pages.add(PageData())
                out.add(Notebook(o.getString("id"), o.getString("title"), o.getLong("color"), o.getString("paper"), pages, o.getLong("updated")))
            }
            out
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun encode(list: List<Notebook>): String {
        val arr = JSONArray()
        for (n in list) {
            val o = JSONObject()
                .put("id", n.id).put("title", n.title).put("color", n.color)
                .put("paper", n.paper).put("updated", n.updated)
            val pages = JSONArray()
            for (pg in n.pages) {
                val ss = JSONArray()
                for (s in pg.strokes) {
                    val flat = JSONArray()
                    for (p in s.pts) {
                        flat.put(p.x.toDouble()); flat.put(p.y.toDouble()); flat.put(p.p.toDouble())
                    }
                    ss.put(JSONObject().put("t", s.tool.toString()).put("c", s.color).put("w", s.width.toDouble()).put("p", flat))
                }
                pages.put(ss)
            }
            o.put("pages", pages)
            arr.put(o)
        }
        return arr.toString()
    }

    fun write(c: Context, json: String) {
        val tmp = File(c.filesDir, "notebooks.tmp")
        tmp.writeText(json)
        tmp.renameTo(file(c))
    }
}
