package com.example.mynotes

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Paint
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.LruCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.atan2
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

fun textPaint(size: Float, color: Long) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
    this.color = color.toInt()
    textSize = size
}

fun bounds(e: El): Rect = when (e) {
    is StrokeEl -> Rect(e.pts.minOf { it.x }, e.pts.minOf { it.y }, e.pts.maxOf { it.x }, e.pts.maxOf { it.y })
    is ShapeEl -> Rect(min(e.x1, e.x2), min(e.y1, e.y2), max(e.x1, e.x2), max(e.y1, e.y2))
    is TextEl -> {
        val p = textPaint(e.size, e.color)
        val lines = e.text.split("\n")
        Rect(e.x, e.y, e.x + lines.maxOf { p.measureText(it) }, e.y + lines.size * e.size * 1.25f)
    }
    is ImageEl -> Rect(e.x, e.y, e.x + e.w, e.y + e.h)
}

fun move(e: El, dx: Float, dy: Float): El = when (e) {
    is StrokeEl -> e.copy(pts = e.pts.map { it.copy(x = it.x + dx, y = it.y + dy) })
    is ShapeEl -> e.copy(x1 = e.x1 + dx, y1 = e.y1 + dy, x2 = e.x2 + dx, y2 = e.y2 + dy)
    is TextEl -> e.copy(x = e.x + dx, y = e.y + dy)
    is ImageEl -> e.copy(x = e.x + dx, y = e.y + dy)
}

fun dup(e: El, dx: Float, dy: Float): El = when (val m = move(e, dx, dy)) {
    is StrokeEl -> m.copy(id = Ids.next())
    is ShapeEl -> m.copy(id = Ids.next())
    is TextEl -> m.copy(id = Ids.next())
    is ImageEl -> m.copy(id = Ids.next())
}

fun segDist(px: Float, py: Float, x1: Float, y1: Float, x2: Float, y2: Float): Float {
    val dx = x2 - x1
    val dy = y2 - y1
    val l = dx * dx + dy * dy
    val t = if (l == 0f) 0f else (((px - x1) * dx + (py - y1) * dy) / l).coerceIn(0f, 1f)
    return hypot(px - (x1 + t * dx), py - (y1 + t * dy))
}

fun hits(e: El, x: Float, y: Float, r: Float): Boolean = when (e) {
    is StrokeEl -> e.pts.any { hypot(it.x - x, it.y - y) < r }
    is ShapeEl -> if (e.kind == 'l' || e.kind == 'a') segDist(x, y, e.x1, e.y1, e.x2, e.y2) < r
    else bounds(e).inflate(r).contains(Offset(x, y)) && !bounds(e).deflate(r).contains(Offset(x, y))
    else -> bounds(e).inflate(r).contains(Offset(x, y))
}

fun inPoly(poly: List<Offset>, p: Offset): Boolean {
    var c = false
    var j = poly.size - 1
    for (i in poly.indices) {
        val a = poly[i]
        val b = poly[j]
        if ((a.y > p.y) != (b.y > p.y) && p.x < (b.x - a.x) * (p.y - a.y) / (b.y - a.y) + a.x) c = !c
        j = i
    }
    return c
}

object ImageCache {
    lateinit var dir: File
    private val c = object : LruCache<String, ImageBitmap>(48 * 1024 * 1024) {
        override fun sizeOf(key: String, value: ImageBitmap) = value.width * value.height * 4
    }

    fun get(name: String): ImageBitmap? {
        c.get(name)?.let { return it }
        return try {
            val f = File(dir, name)
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, o)
            var s = 1
            while (o.outWidth / s > 1600 || o.outHeight / s > 1600) s *= 2
            val b = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })?.asImageBitmap()
            if (b != null) c.put(name, b)
            b
        } catch (e: Exception) {
            null
        }
    }
}

object PdfCache {
    private val c = object : LruCache<String, ImageBitmap>(48 * 1024 * 1024) {
        override fun sizeOf(key: String, value: ImageBitmap) = value.width * value.height * 4
    }
    private val lock = Mutex()

    suspend fun get(ctx: Context, file: String, page: Int, w: Int): ImageBitmap? = withContext(Dispatchers.IO) {
        val key = "$file:$page:$w"
        c.get(key)?.let { return@withContext it }
        lock.withLock {
            try {
                val pfd = ParcelFileDescriptor.open(File(ctx.filesDir, "pdfs/$file"), ParcelFileDescriptor.MODE_READ_ONLY)
                PdfRenderer(pfd).use { r ->
                    r.openPage(page).use { p ->
                        val h = (w * p.height.toFloat() / p.width).toInt().coerceAtLeast(1)
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(android.graphics.Color.WHITE)
                        p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        val ib = bmp.asImageBitmap()
                        c.put(key, ib)
                        ib
                    }
                }
            } catch (e: Exception) {
                null
            }
        }
    }
}

fun DrawScope.drawStroke(pts: List<Pt>, tool: Char, color: Long, width: Float, sc: Float) {
    if (pts.isEmpty()) return
    val col = Color(color)
    val a = if (tool == 'h') 0.35f else 1f
    if (pts.size == 1) {
        drawCircle(col, radius = width * sc * 0.6f, center = Offset(pts[0].x * sc, pts[0].y * sc), alpha = a)
        return
    }
    val path = Path()
    path.moveTo(pts[0].x * sc, pts[0].y * sc)
    for (i in 1 until pts.size) {
        val p0 = pts[i - 1]
        val p1 = pts[i]
        path.quadraticBezierTo(p0.x * sc, p0.y * sc, (p0.x + p1.x) / 2 * sc, (p0.y + p1.y) / 2 * sc)
    }
    path.lineTo(pts.last().x * sc, pts.last().y * sc)
    val avg = pts.map { it.p }.average().toFloat()
    val sw = if (tool == 'h') width * 5f * sc else width * sc * (0.6f + avg * 0.8f)
    drawPath(path, col, alpha = a, style = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

fun DrawScope.drawShape(e: ShapeEl, sc: Float) {
    val col = Color(e.color)
    val sw = e.width * sc * 1.2f
    val a = Offset(e.x1 * sc, e.y1 * sc)
    val b = Offset(e.x2 * sc, e.y2 * sc)
    when (e.kind) {
        'l' -> drawLine(col, a, b, sw, StrokeCap.Round)
        'a' -> {
            drawLine(col, a, b, sw, StrokeCap.Round)
            val ang = atan2(b.y - a.y, b.x - a.x)
            val hl = 12f * sc + sw * 2
            val pi = Math.PI.toFloat()
            for (d in listOf(pi + 0.45f, pi - 0.45f)) {
                drawLine(col, b, Offset(b.x + hl * cos(ang + d), b.y + hl * sin(ang + d)), sw, StrokeCap.Round)
            }
        }
        'r' -> drawRect(col, Offset(min(a.x, b.x), min(a.y, b.y)), Size(abs(b.x - a.x), abs(b.y - a.y)), style = Stroke(sw))
        else -> drawOval(col, Offset(min(a.x, b.x), min(a.y, b.y)), Size(abs(b.x - a.x), abs(b.y - a.y)), style = Stroke(sw))
    }
}

fun DrawScope.drawTextEl(e: TextEl, sc: Float) {
    val p = textPaint(e.size * sc, e.color)
    var y = e.y * sc - p.fontMetrics.ascent
    for (ln in e.text.split("\n")) {
        drawContext.canvas.nativeCanvas.drawText(ln, e.x * sc, y, p)
        y += e.size * sc * 1.25f
    }
}

fun DrawScope.drawEl(e: El, sc: Float) {
    when (e) {
        is StrokeEl -> drawStroke(e.pts, e.tool, e.color, e.width, sc)
        is ShapeEl -> drawShape(e, sc)
        is TextEl -> drawTextEl(e, sc)
        is ImageEl -> ImageCache.get(e.file)?.let {
            drawImage(it, dstOffset = IntOffset((e.x * sc).roundToInt(), (e.y * sc).roundToInt()),
                dstSize = IntSize((e.w * sc).roundToInt(), (e.h * sc).roundToInt()))
        }
    }
}

fun DrawScope.drawElements(els: List<El>, sc: Float) = els.forEach { drawEl(it, sc) }

fun DrawScope.drawPaperPattern(paper: String, sc: Float, h: Float) {
    val lc = Color(0xFFD5DAE6)
    val step = 32f * sc
    val w = PW * sc
    val hh = h * sc
    when (paper) {
        "lined" -> { var y = step; while (y < hh) { drawLine(lc, Offset(0f, y), Offset(w, y), 1.5f); y += step } }
        "grid" -> {
            var y = step; while (y < hh) { drawLine(lc, Offset(0f, y), Offset(w, y), 1.5f); y += step }
            var x = step; while (x < w) { drawLine(lc, Offset(x, 0f), Offset(x, hh), 1.5f); x += step }
        }
        "dotted", "infinite" -> {
            var y = step
            while (y < hh) {
                var x = step
                while (x < w) { drawCircle(Color(0xFF8A90A0), radius = 1.8f, center = Offset(x, y)); x += step }
                y += step
            }
        }
    }
}

fun DrawScope.drawInfiniteDots(vis: Rect, sc: Float) {
    var s = 32f
    while ((vis.width / s) * (vis.height / s) > 6000f) s *= 2f
    var y = floor(vis.top / s) * s
    while (y < vis.bottom) {
        var x = floor(vis.left / s) * s
        while (x < vis.right) { drawCircle(Color(0xFF8A90A0), 1.8f, Offset(x * sc, y * sc)); x += s }
        y += s
    }
}

fun DrawScope.drawPageBase(paper: String, pdf: ImageBitmap?, h: Float, sc: Float) {
    drawRect(Color.White, size = Size(PW * sc, h * sc))
    if (pdf != null) drawImage(pdf, dstSize = IntSize((PW * sc).roundToInt(), (h * sc).roundToInt()))
    else drawPaperPattern(paper, sc, h)
}
