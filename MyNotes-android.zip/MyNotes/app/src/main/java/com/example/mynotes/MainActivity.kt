package com.example.mynotes

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.hypot

val COVERS = listOf(0xFF4F46E5L, 0xFF0F766E, 0xFFB4234AL, 0xFF9A5B00L, 0xFF334155L, 0xFF6D28D9L)
val INKS = listOf("Black" to 0xFF17181CL, "Indigo" to 0xFF4F46E5L, "Red" to 0xFFDC2626L, "Green" to 0xFF16A34AL, "Yellow" to 0xFFFACC15L)
val PAPERS = listOf("blank", "lined", "grid", "dotted")
const val PW = 800f
const val PH = 1100f

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { Root() } }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme())
        darkColorScheme(primary = Color(0xFF8B85FF), onPrimary = Color(0xFF101116))
    else lightColorScheme(primary = Color(0xFF4F46E5))
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun Root() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val books = remember { mutableStateListOf<Notebook>().also { it.addAll(Store.load(ctx)) } }
    var open by remember { mutableStateOf<Notebook?>(null) }
    var ver by remember { mutableIntStateOf(0) }
    val job = remember { arrayOfNulls<Job>(1) }
    fun persist() {
        job[0]?.cancel()
        job[0] = scope.launch {
            delay(400)
            val json = Store.encode(books)
            withContext(Dispatchers.IO) { Store.write(ctx, json) }
        }
    }
    val cur = open
    if (cur == null) {
        Library(
            books = books, ver = ver,
            onOpen = { open = it },
            onCreate = { t, c, p ->
                val n = Notebook("n${System.currentTimeMillis()}", t, c, p, mutableListOf(PageData()), System.currentTimeMillis())
                books.add(0, n); persist(); open = n
            },
            onDelete = { books.remove(it); persist() }
        )
    } else {
        BackHandler { ver++; persist(); open = null }
        Editor(cur, onChanged = { persist() }, onBack = { ver++; persist(); open = null })
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Library(
    books: List<Notebook>, ver: Int,
    onOpen: (Notebook) -> Unit,
    onCreate: (String, Long, String) -> Unit,
    onDelete: (Notebook) -> Unit
) {
    key(ver) {
        var show by remember { mutableStateOf(false) }
        var confirm by remember { mutableStateOf<String?>(null) }
        Scaffold(
            topBar = { TopAppBar(title = { Text("My Notes") }) },
            floatingActionButton = {
                ExtendedFloatingActionButton(
                    onClick = { show = true },
                    icon = { Icon(Icons.Default.Add, contentDescription = null) },
                    text = { Text("New notebook") }
                )
            }
        ) { pad ->
            if (books.isEmpty()) {
                Box(Modifier.padding(pad).fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text("No notebooks yet. Tap New notebook to start writing.")
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(150.dp),
                    modifier = Modifier.padding(pad).fillMaxSize(),
                    contentPadding = PaddingValues(20.dp, 20.dp, 20.dp, 100.dp),
                    horizontalArrangement = Arrangement.spacedBy(20.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    items(books, key = { it.id }) { n ->
                        Column {
                            Box(
                                Modifier.fillMaxWidth().height(190.dp)
                                    .clip(RoundedCornerShape(8.dp, 12.dp, 12.dp, 8.dp))
                                    .background(Color(n.color))
                                    .clickable(onClickLabel = "Open ${n.title}") { onOpen(n) }
                                    .padding(14.dp)
                            ) { Text(n.title, color = Color.White, fontWeight = FontWeight.Bold) }
                            Text(
                                "${n.pages.size} " + if (n.pages.size == 1) "page" else "pages",
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(top = 8.dp)
                            )
                            TextButton(onClick = {
                                if (confirm == n.id) { onDelete(n); confirm = null } else confirm = n.id
                            }) { Text(if (confirm == n.id) "Tap again to delete" else "Delete") }
                        }
                    }
                }
            }
        }
        if (show) NewDialog(onDismiss = { show = false }, onCreate = { t, c, p -> show = false; onCreate(t, c, p) })
    }
}

@Composable
fun NewDialog(onDismiss: () -> Unit, onCreate: (String, Long, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var color by remember { mutableLongStateOf(COVERS[0]) }
    var paper by remember { mutableStateOf("lined") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New notebook") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true)
                Text("Cover")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    COVERS.forEach { c ->
                        Box(
                            Modifier.size(32.dp).clip(CircleShape).background(Color(c))
                                .border(if (c == color) 3.dp else 0.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                .clickable(onClickLabel = "Choose cover colour") { color = c }
                        )
                    }
                }
                Text("Paper")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PAPERS.forEach { p ->
                        FilterChip(selected = paper == p, onClick = { paper = p }, label = { Text(p.replaceFirstChar { it.uppercase() }) })
                    }
                }
            }
        },
        confirmButton = { Button(onClick = { onCreate(name.ifBlank { "Untitled" }, color, paper) }) { Text("Create notebook") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

class PageInk(private val page: PageData, private val onSave: () -> Unit) {
    var strokes by mutableStateOf(page.strokes)
    var live by mutableStateOf<List<Pt>>(emptyList())
    var undo by mutableStateOf<List<List<InkStroke>>>(emptyList())
    var redo by mutableStateOf<List<List<InkStroke>>>(emptyList())
    private var erased = false

    private fun set(n: List<InkStroke>) { strokes = n; page.strokes = n; onSave() }
    fun commit(s: InkStroke) { undo = undo + listOf(strokes); redo = emptyList(); set(strokes + s) }
    fun beginErase() { erased = false }
    fun erase(x: Float, y: Float) {
        val n = strokes.filter { s -> s.pts.none { hypot(it.x - x, it.y - y) < 16f } }
        if (n.size != strokes.size) {
            if (!erased) { undo = undo + listOf(strokes); redo = emptyList(); erased = true }
            set(n)
        }
    }
    fun doUndo() {
        if (undo.isEmpty()) return
        redo = redo + listOf(strokes)
        val p = undo.last(); undo = undo.dropLast(1); set(p)
    }
    fun doRedo() {
        if (redo.isEmpty()) return
        undo = undo + listOf(strokes)
        val p = redo.last(); redo = redo.dropLast(1); set(p)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Editor(nb: Notebook, onChanged: () -> Unit, onBack: () -> Unit) {
    var pageIdx by remember { mutableIntStateOf(0) }
    var pageCount by remember { mutableIntStateOf(nb.pages.size) }
    var title by remember { mutableStateOf(nb.title) }
    var tool by remember { mutableStateOf('p') }
    var color by remember { mutableLongStateOf(INKS[0].second) }
    var size by remember { mutableFloatStateOf(3f) }
    var penOnly by remember { mutableStateOf(false) }
    val ink = remember(pageIdx) {
        PageInk(nb.pages[pageIdx]) { nb.updated = System.currentTimeMillis(); onChanged() }
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    BasicTextField(
                        value = title,
                        onValueChange = { title = it; nb.title = it.ifBlank { "Untitled" }; onChanged() },
                        singleLine = true,
                        textStyle = TextStyle(color = LocalContentColor.current, fontSize = 20.sp),
                        cursorBrush = SolidColor(LocalContentColor.current)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to notebooks") }
                },
                actions = {
                    IconButton(enabled = pageIdx > 0, onClick = { pageIdx-- }) { Text("‹", fontSize = 26.sp) }
                    Text("${pageIdx + 1}/$pageCount")
                    IconButton(enabled = pageIdx < pageCount - 1, onClick = { pageIdx++ }) { Text("›", fontSize = 26.sp) }
                    IconButton(onClick = {
                        nb.pages.add(PageData()); pageCount = nb.pages.size; pageIdx = nb.pages.size - 1; onChanged()
                    }) { Icon(Icons.Default.Add, contentDescription = "Add page") }
                }
            )
        },
        bottomBar = {
            Toolbar(
                ink = ink, tool = tool,
                onTool = { tool = it; if (it == 'h' && color == INKS[0].second) color = INKS[4].second },
                color = color, onColor = { color = it; if (tool == 'e') tool = 'p' },
                size = size, onSize = { size = it },
                penOnly = penOnly, onPenOnly = { penOnly = it }
            )
        }
    ) { pad ->
        BoxWithConstraints(
            Modifier.padding(pad).fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant).padding(12.dp),
            contentAlignment = Alignment.Center
        ) {
            val w = minOf(maxWidth, maxHeight * (PW / PH))
            PageCanvas(Modifier.width(w).aspectRatio(PW / PH), nb.paper, ink, tool, color, size, penOnly)
        }
    }
}

@Composable
fun Toolbar(
    ink: PageInk, tool: Char, onTool: (Char) -> Unit,
    color: Long, onColor: (Long) -> Unit,
    size: Float, onSize: (Float) -> Unit,
    penOnly: Boolean, onPenOnly: (Boolean) -> Unit
) {
    Surface(tonalElevation = 3.dp) {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf('p' to "Pen", 'h' to "Highlighter", 'e' to "Eraser").forEach { (t, label) ->
                FilterChip(selected = tool == t, onClick = { onTool(t) }, label = { Text(label) })
            }
            Spacer(Modifier.width(6.dp))
            INKS.forEach { (name, c) ->
                Box(Modifier.size(48.dp).clickable(onClickLabel = "$name ink") { onColor(c) }, contentAlignment = Alignment.Center) {
                    Box(
                        Modifier.size(28.dp).clip(CircleShape).background(Color(c))
                            .border(if (color == c) 3.dp else 1.dp, if (color == c) MaterialTheme.colorScheme.primary else Color.Gray, CircleShape)
                    )
                }
            }
            Spacer(Modifier.width(6.dp))
            listOf(2f to "Thin", 3f to "Medium", 7f to "Thick").forEach { (z, label) ->
                FilterChip(selected = size == z, onClick = { onSize(z) }, label = { Text(label) })
            }
            Spacer(Modifier.width(6.dp))
            TextButton(enabled = ink.undo.isNotEmpty(), onClick = { ink.doUndo() }) { Text("Undo") }
            TextButton(enabled = ink.redo.isNotEmpty(), onClick = { ink.doRedo() }) { Text("Redo") }
            FilterChip(selected = penOnly, onClick = { onPenOnly(!penOnly) }, label = { Text("Pen only") })
        }
    }
}

@Composable
fun PageCanvas(mod: Modifier, paper: String, ink: PageInk, tool: Char, color: Long, width: Float, penOnly: Boolean) {
    val t = rememberUpdatedState(tool)
    val c = rememberUpdatedState(color)
    val w = rememberUpdatedState(width)
    val po = rememberUpdatedState(penOnly)
    val inkS = rememberUpdatedState(ink)
    Canvas(
        mod.background(Color.White).pointerInput(Unit) {
            awaitEachGesture {
                val sc = size.width / PW
                val down = awaitFirstDown(requireUnconsumed = false)
                if (po.value && down.type == PointerType.Touch) return@awaitEachGesture
                val erasing = t.value == 'e' || down.type == PointerType.Eraser
                val pts = ArrayList<Pt>()
                fun add(ch: PointerInputChange) {
                    pts.add(Pt(ch.position.x / sc, ch.position.y / sc, if (ch.pressure > 0f) ch.pressure else 0.5f))
                }
                down.consume()
                val k = inkS.value
                if (erasing) { k.beginErase(); k.erase(down.position.x / sc, down.position.y / sc) }
                else { add(down); k.live = pts.toList() }
                while (true) {
                    val ev = awaitPointerEvent()
                    val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                    if (!ch.pressed) break
                    if (erasing) k.erase(ch.position.x / sc, ch.position.y / sc) else { add(ch); k.live = pts.toList() }
                    ch.consume()
                }
                if (!erasing && pts.isNotEmpty()) {
                    k.commit(InkStroke(if (t.value == 'h') 'h' else 'p', c.value, w.value, pts.toList()))
                }
                k.live = emptyList()
            }
        }
    ) {
        val sc = size.width / PW
        drawPaper(paper, sc)
        ink.strokes.forEach { drawInk(it.pts, it.tool, it.color, it.width, sc) }
        if (ink.live.isNotEmpty()) drawInk(ink.live, if (t.value == 'h') 'h' else 'p', c.value, w.value, sc)
    }
}

fun DrawScope.drawPaper(paper: String, sc: Float) {
    val lc = Color(0xFFD5DAE6)
    val step = 32f * sc
    when (paper) {
        "lined" -> { var y = step; while (y < size.height) { drawLine(lc, Offset(0f, y), Offset(size.width, y), 1.5f); y += step } }
        "grid" -> {
            var y = step; while (y < size.height) { drawLine(lc, Offset(0f, y), Offset(size.width, y), 1.5f); y += step }
            var x = step; while (x < size.width) { drawLine(lc, Offset(x, 0f), Offset(x, size.height), 1.5f); x += step }
        }
        "dotted" -> {
            var y = step
            while (y < size.height) {
                var x = step
                while (x < size.width) { drawCircle(Color(0xFF8A90A0), radius = 1.8f, center = Offset(x, y)); x += step }
                y += step
            }
        }
    }
}

fun DrawScope.drawInk(pts: List<Pt>, tool: Char, color: Long, width: Float, sc: Float) {
    if (pts.isEmpty()) return
    val col = Color(color)
    val a = if (tool == 'h') 0.35f else 1f
    if (pts.size == 1) {
        drawCircle(col, radius = width * sc * 0.6f, center = Offset(pts[0].x * sc, pts[0].y * sc), alpha = a)
        return
    }
    val path = Path()
    path.moveTo(pts[0].x * sc, pts[0].y * sc)
    for (i in 1 until pts.size) {
        val p0 = pts[i - 1]; val p1 = pts[i]
        path.quadraticBezierTo(p0.x * sc, p0.y * sc, (p0.x + p1.x) / 2 * sc, (p0.y + p1.y) / 2 * sc)
    }
    path.lineTo(pts.last().x * sc, pts.last().y * sc)
    val avg = pts.map { it.p }.average().toFloat()
    val sw = if (tool == 'h') width * 5f * sc else width * sc * (0.6f + avg * 0.8f)
    drawPath(path, col, alpha = a, style = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
}
