package com.example.mynotes

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.AwaitPointerEventScope
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.min

val INKS = listOf("Black" to 0xFF17181CL, "Indigo" to 0xFF4F46E5L, "Red" to 0xFFDC2626L, "Green" to 0xFF16A34AL, "Yellow" to 0xFFFACC15L)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        File(filesDir, "images").mkdirs()
        File(filesDir, "pdfs").mkdirs()
        ImageCache.dir = File(filesDir, "images")
        setContent { AppTheme { Root() } }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme())
        darkColorScheme(primary = Color(0xFF8B85FF), onPrimary = Color(0xFF101116))
    else lightColorScheme(primary = Color(0xFF4F46E5))
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun Root() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val data = remember { Store.load(ctx) }
    val books = remember { mutableStateListOf<Notebook>().also { it.addAll(data.books) } }
    val folders = remember { mutableStateListOf<String>().also { it.addAll(data.folders) } }
    var open by remember { mutableStateOf<Notebook?>(null) }
    var ver by remember { mutableIntStateOf(0) }
    var filter by remember { mutableStateOf("all") }
    var query by remember { mutableStateOf("") }
    var exportNb by remember { mutableStateOf<Notebook?>(null) }
    val job = remember { arrayOfNulls<Job>(1) }
    fun persist() {
        job[0]?.cancel()
        job[0] = scope.launch {
            delay(400)
            val json = Store.encode(books, folders)
            withContext(Dispatchers.IO) { Store.write(ctx, json) }
        }
    }
    fun changed() { ver++; persist() }

    val pdfPick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { importPdf(ctx, uri, displayName(ctx, uri))?.let { books.add(0, it); changed() } }
    }
    val backupL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) scope.launch { backup(ctx, books.toList(), folders.toList(), uri) }
    }
    val restoreL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            restore(ctx, uri)?.let { d ->
                d.books.filter { b -> books.none { it.id == b.id } }.forEach { books.add(it) }
                d.folders.filter { it !in folders }.forEach { folders.add(it) }
                changed()
            }
        }
    }
    val exportL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val n = exportNb
        if (uri != null && n != null) scope.launch { exportPdf(ctx, n, uri) }
    }

    val cur = open
    if (cur == null) {
        Library(
            books = books, folders = folders, ver = ver,
            filter = filter, onFilter = { filter = it }, query = query, onQuery = { query = it },
            onOpen = { open = it },
            onCreate = { t, c, p ->
                val n = Notebook("n${System.currentTimeMillis()}", t, c, p, mutableListOf(PageData()), System.currentTimeMillis())
                if (filter.startsWith("f:")) n.folder = filter.substring(2)
                books.add(0, n); persist(); open = n
            },
            onChange = { changed() },
            onNewFolder = { if (it.isNotBlank() && it !in folders) { folders.add(it); changed() } },
            onDeleteFolder = { f -> books.filter { it.folder == f }.forEach { it.folder = "" }; folders.remove(f); filter = "all"; changed() },
            onDeleteForever = { n -> books.remove(n); if (n.pdf.isNotEmpty()) File(ctx.filesDir, "pdfs/${n.pdf}").delete(); changed() },
            onImportPdf = { pdfPick.launch(arrayOf("application/pdf")) },
            onBackup = { backupL.launch("my-notes-backup.zip") },
            onRestore = { restoreL.launch(arrayOf("*/*")) },
            onExport = { exportNb = it; exportL.launch("${it.title}.pdf") }
        )
    } else {
        BackHandler { changed(); open = null }
        Editor(cur, onChanged = { persist() }, onBack = { changed(); open = null })
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Library(
    books: List<Notebook>, folders: List<String>, ver: Int,
    filter: String, onFilter: (String) -> Unit, query: String, onQuery: (String) -> Unit,
    onOpen: (Notebook) -> Unit, onCreate: (String, Long, String) -> Unit, onChange: () -> Unit,
    onNewFolder: (String) -> Unit, onDeleteFolder: (String) -> Unit, onDeleteForever: (Notebook) -> Unit,
    onImportPdf: () -> Unit, onBackup: () -> Unit, onRestore: () -> Unit, onExport: (Notebook) -> Unit
) {
    key(ver) {
        var show by remember { mutableStateOf(false) }
        var topMenu by remember { mutableStateOf(false) }
        var menuFor by remember { mutableStateOf<String?>(null) }
        var moveTarget by remember { mutableStateOf<Notebook?>(null) }
        var folderDialog by remember { mutableStateOf(false) }
        val q = query.trim().lowercase()
        val list = books.filter { n ->
            val inFilter = when {
                filter == "trash" -> n.trash
                n.trash -> false
                filter == "fav" -> n.fav
                filter.startsWith("f:") -> n.folder == filter.substring(2)
                else -> true
            }
            inFilter && (q.isEmpty() || n.title.lowercase().contains(q) ||
                n.pages.any { p -> p.els.any { it is TextEl && it.text.lowercase().contains(q) } })
        }
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("My Notes") },
                    actions = {
                        Box {
                            IconButton(onClick = { topMenu = true }) { Text("⋮", fontSize = 22.sp) }
                            DropdownMenu(expanded = topMenu, onDismissRequest = { topMenu = false }) {
                                DropdownMenuItem(text = { Text("Import PDF") }, onClick = { topMenu = false; onImportPdf() })
                                DropdownMenuItem(text = { Text("New folder") }, onClick = { topMenu = false; folderDialog = true })
                                DropdownMenuItem(text = { Text("Back up library") }, onClick = { topMenu = false; onBackup() })
                                DropdownMenuItem(text = { Text("Restore backup") }, onClick = { topMenu = false; onRestore() })
                            }
                        }
                    }
                )
            },
            floatingActionButton = {
                ExtendedFloatingActionButton(
                    onClick = { show = true },
                    icon = { Icon(Icons.Default.Add, contentDescription = null) },
                    text = { Text("New notebook") }
                )
            }
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                OutlinedTextField(
                    value = query, onValueChange = onQuery, singleLine = true,
                    label = { Text("Search titles and text") },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                )
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(selected = filter == "all", onClick = { onFilter("all") }, label = { Text("All") })
                    FilterChip(selected = filter == "fav", onClick = { onFilter("fav") }, label = { Text("Favorites") })
                    folders.forEach { f ->
                        FilterChip(selected = filter == "f:$f", onClick = { onFilter("f:$f") }, label = { Text(f) })
                    }
                    FilterChip(selected = filter == "trash", onClick = { onFilter("trash") }, label = { Text("Trash") })
                }
                if (filter.startsWith("f:")) {
                    TextButton(onClick = { onDeleteFolder(filter.substring(2)) }, modifier = Modifier.padding(start = 8.dp)) {
                        Text("Delete this folder (notebooks are kept)")
                    }
                }
                if (list.isEmpty()) {
                    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(if (books.isEmpty()) "No notebooks yet. Tap New notebook or import a PDF." else "Nothing here.")
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(150.dp),
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(20.dp, 16.dp, 20.dp, 100.dp),
                        horizontalArrangement = Arrangement.spacedBy(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(list, key = { it.id }) { n ->
                            Column {
                                Box(
                                    Modifier.fillMaxWidth().height(190.dp)
                                        .clip(RoundedCornerShape(8.dp, 12.dp, 12.dp, 8.dp))
                                        .background(Color(n.color))
                                        .clickable(onClickLabel = "Open ${n.title}") { if (!n.trash) onOpen(n) }
                                        .padding(14.dp)
                                ) {
                                    Text(
                                        (if (n.fav) "★ " else "") + n.title + if (n.pdf.isNotEmpty()) "\n(PDF)" else "",
                                        color = Color.White, fontWeight = FontWeight.Bold
                                    )
                                }
                                Text(
                                    "${n.pages.size} " + if (n.pages.size == 1) "page" else "pages",
                                    style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp)
                                )
                                Box {
                                    TextButton(onClick = { menuFor = n.id }) { Text("Options") }
                                    DropdownMenu(expanded = menuFor == n.id, onDismissRequest = { menuFor = null }) {
                                        if (n.trash) {
                                            DropdownMenuItem(text = { Text("Restore") }, onClick = { menuFor = null; n.trash = false; onChange() })
                                            DropdownMenuItem(text = { Text("Delete forever") }, onClick = { menuFor = null; onDeleteForever(n) })
                                        } else {
                                            DropdownMenuItem(
                                                text = { Text(if (n.fav) "Remove from favorites" else "Add to favorites") },
                                                onClick = { menuFor = null; n.fav = !n.fav; onChange() }
                                            )
                                            DropdownMenuItem(text = { Text("Move to folder") }, onClick = { menuFor = null; moveTarget = n })
                                            DropdownMenuItem(text = { Text("Export as PDF") }, onClick = { menuFor = null; onExport(n) })
                                            DropdownMenuItem(text = { Text("Move to trash") }, onClick = { menuFor = null; n.trash = true; onChange() })
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (show) NewDialog(onDismiss = { show = false }, onCreate = { t, c, p -> show = false; onCreate(t, c, p) })
        if (folderDialog) {
            var fname by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { folderDialog = false },
                title = { Text("New folder") },
                text = { OutlinedTextField(value = fname, onValueChange = { fname = it }, label = { Text("Folder name") }, singleLine = true) },
                confirmButton = { Button(onClick = { folderDialog = false; onNewFolder(fname.trim()) }) { Text("Create folder") } },
                dismissButton = { TextButton(onClick = { folderDialog = false }) { Text("Cancel") } }
            )
        }
        moveTarget?.let { n ->
            AlertDialog(
                onDismissRequest = { moveTarget = null },
                title = { Text("Move to folder") },
                text = {
                    Column {
                        TextButton(onClick = { n.folder = ""; moveTarget = null; onChange() }) { Text("No folder") }
                        folders.forEach { f -> TextButton(onClick = { n.folder = f; moveTarget = null; onChange() }) { Text(f) } }
                        if (folders.isEmpty()) Text("Create a folder first from the menu at the top.")
                    }
                },
                confirmButton = {},
                dismissButton = { TextButton(onClick = { moveTarget = null }) { Text("Cancel") } }
            )
        }
    }
}

@Composable
fun NewDialog(onDismiss: () -> Unit, onCreate: (String, Long, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var color by remember { mutableLongStateOf(COVERS[0]) }
    var paper by remember { mutableStateOf("lined") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New notebook") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true)
                Text("Cover")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    COVERS.forEach { c ->
                        Box(
                            Modifier.size(32.dp).clip(CircleShape).background(Color(c))
                                .border(if (c == color) 3.dp else 0.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                .clickable(onClickLabel = "Choose cover colour") { color = c }
                        )
                    }
                }
                Text("Paper")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PAPERS.forEach { p ->
                        FilterChip(selected = paper == p, onClick = { paper = p }, label = { Text(p.replaceFirstChar { it.uppercase() }) })
                    }
                }
            }
        },
        confirmButton = { Button(onClick = { onCreate(name.ifBlank { "Untitled" }, color, paper) }) { Text("Create notebook") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

class ToolState {
    var tool by mutableStateOf('p')
    var shape by mutableStateOf('r')
    var color by mutableLongStateOf(INKS[0].second)
    var size by mutableFloatStateOf(3f)
    var penOnly by mutableStateOf(false)
}

class ViewState {
    var z by mutableFloatStateOf(1f)
    var ox by mutableFloatStateOf(12f)
    var oy by mutableFloatStateOf(12f)
    var cw = 1f
    var chh = 1f
    fun reset() { z = 1f; ox = 12f; oy = 12f }
    fun center(): Offset {
        val sc = (cw - 24f) / PW
        return Offset((cw / 2 - ox) / z / sc, (chh / 2 - oy) / z / sc)
    }
}

class PageInk(private val page: PageData, private val onSave: () -> Unit) {
    var els by mutableStateOf(page.els)
    var sel by mutableStateOf<Set<Long>>(emptySet())
    var live by mutableStateOf<El?>(null)
    var lasso by mutableStateOf<List<Offset>>(emptyList())
    var undo by mutableStateOf<List<List<El>>>(emptyList())
    var redo by mutableStateOf<List<List<El>>>(emptyList())
    private var erased = false

    private fun commit(n: List<El>) { els = n; page.els = n; onSave() }
    private fun push() { undo = undo + listOf(els); redo = emptyList() }
    fun add(e: El) { push(); commit(els + e) }
    fun replace(e: El) { push(); commit(els.map { if (it.id == e.id) e else it }) }
    fun remove(id: Long) { push(); commit(els.filter { it.id != id }) }
    fun beginErase() { erased = false }
    fun erase(x: Float, y: Float) {
        val n = els.filter { !hits(it, x, y, 16f) }
        if (n.size != els.size) {
            if (!erased) { push(); erased = true }
            commit(n)
            sel = sel intersect n.map { it.id }.toSet()
        }
    }
    fun doUndo() {
        if (undo.isEmpty()) return
        redo = redo + listOf(els)
        val p = undo.last(); undo = undo.dropLast(1); sel = emptySet(); commit(p)
    }
    fun doRedo() {
        if (redo.isEmpty()) return
        undo = undo + listOf(els)
        val p = redo.last(); redo = redo.dropLast(1); sel = emptySet(); commit(p)
    }
    fun selectIn(poly: List<Offset>) {
        if (poly.size < 3) { sel = emptySet(); return }
        sel = els.filter { inPoly(poly, bounds(it).center) }.map { it.id }.toSet()
    }
    fun selBounds(): Rect? {
        val bs = els.filter { it.id in sel }.map { bounds(it) }
        if (bs.isEmpty()) return null
        return Rect(bs.minOf { it.left }, bs.minOf { it.top }, bs.maxOf { it.right }, bs.maxOf { it.bottom })
    }
    fun beginMove() { push() }
    fun moveSel(dx: Float, dy: Float) { commit(els.map { if (it.id in sel) move(it, dx, dy) else it }) }
    fun deleteSel() { push(); commit(els.filter { it.id !in sel }); sel = emptySet() }
    fun duplicateSel() {
        push()
        val d = els.filter { it.id in sel }.map { dup(it, 24f, 24f) }
        commit(els + d)
        sel = d.map { it.id }.toSet()
    }
}

class TextTarget(val x: Float, val y: Float, val el: TextEl?)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Editor(nb: Notebook, onChanged: () -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pageIdx by remember { mutableIntStateOf(0) }
    var pagesVer by remember { mutableIntStateOf(0) }
    var title by remember { mutableStateOf(nb.title) }
    var showPages by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var textTarget by remember { mutableStateOf<TextTarget?>(null) }
    val ts = remember { ToolState() }
    val view = remember { ViewState() }
    val idx = pageIdx.coerceIn(0, nb.pages.size - 1)
    val page = nb.pages[idx]
    val ink = remember(page, pagesVer) { PageInk(page) { nb.updated = System.currentTimeMillis(); onChanged() } }
    val pdfBmp by produceState<ImageBitmap?>(null, nb.pdf, page.pdfPage) {
        value = null
        value = if (page.pdfPage >= 0) PdfCache.get(ctx, nb.pdf, page.pdfPage, 1600) else null
    }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            importImage(ctx, uri)?.let { (f, asp) ->
                val c = view.center()
                ink.add(ImageEl(Ids.next(), f, c.x - 150f, c.y - 150f * asp / 2, 300f, 300f * asp))
            }
        }
    }
    val exportL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) scope.launch { exportPdf(ctx, nb, uri) }
    }
    LaunchedEffect(page) { view.reset() }
    BackHandler(enabled = showPages) { showPages = false }

    if (showPages) {
        PagesScreen(nb, idx, pagesVer,
            onPick = { pageIdx = it; showPages = false },
            onChange = { ni -> pageIdx = ni; pagesVer++; onChanged() },
            onBack = { showPages = false })
        return
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    BasicTextField(
                        value = title,
                        onValueChange = { title = it; nb.title = it.ifBlank { "Untitled" }; onChanged() },
                        singleLine = true,
                        textStyle = TextStyle(color = LocalContentColor.current, fontSize = 20.sp),
                        cursorBrush = SolidColor(LocalContentColor.current)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to notebooks") }
                },
                actions = {
                    IconButton(enabled = idx > 0, onClick = { pageIdx = idx - 1 }) { Text("‹", fontSize = 26.sp) }
                    Text("${idx + 1}/${nb.pages.size}")
                    IconButton(enabled = idx < nb.pages.size - 1, onClick = { pageIdx = idx + 1 }) { Text("›", fontSize = 26.sp) }
                    IconButton(onClick = {
                        nb.pages.add(idx + 1, PageData(h = page.h.takeIf { page.pdfPage < 0 } ?: 1100f))
                        pageIdx = idx + 1; pagesVer++; onChanged()
                    }) { Icon(Icons.Default.Add, contentDescription = "Add page") }
                    Box {
                        IconButton(onClick = { menu = true }) { Text("⋮", fontSize = 22.sp) }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text("Pages overview") }, onClick = { menu = false; showPages = true })
                            PAPERS.forEach { p ->
                                DropdownMenuItem(
                                    text = { Text("Template: " + p.replaceFirstChar { it.uppercase() }) },
                                    onClick = { menu = false; page.paper = p; onChanged() }
                                )
                            }
                            DropdownMenuItem(text = { Text("Reset zoom") }, onClick = { menu = false; view.reset() })
                            DropdownMenuItem(text = { Text("Export notebook as PDF") }, onClick = { menu = false; exportL.launch("${nb.title}.pdf") })
                        }
                    }
                }
            )
        },
        bottomBar = { Toolbar(ink, ts) { pickImage.launch("image/*") } }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            PageCanvas(nb, page, ink, pdfBmp, ts, view) { p ->
                val hit = ink.els.lastOrNull { it is TextEl && bounds(it).inflate(8f).contains(p) } as TextEl?
                textTarget = TextTarget(p.x, p.y, hit)
            }
            if (ink.sel.isNotEmpty()) {
                Surface(
                    Modifier.align(Alignment.TopCenter).padding(8.dp),
                    shape = RoundedCornerShape(24.dp), tonalElevation = 6.dp, shadowElevation = 4.dp
                ) {
                    Row(Modifier.padding(horizontal = 8.dp)) {
                        TextButton(onClick = { ink.duplicateSel() }) { Text("Duplicate") }
                        TextButton(onClick = { ink.deleteSel() }) { Text("Delete") }
                        TextButton(onClick = { ink.sel = emptySet() }) { Text("Done") }
                    }
                }
            }
        }
    }
    textTarget?.let { tt ->
        var text by remember(tt) { mutableStateOf(tt.el?.text ?: "") }
        val fs = when (ts.size) { 2f -> 20f; 3f -> 28f; else -> 44f }
        AlertDialog(
            onDismissRequest = { textTarget = null },
            title = { Text(if (tt.el == null) "Add text" else "Edit text") },
            text = { OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text("Text") }, minLines = 2) },
            confirmButton = {
                Button(onClick = {
                    val e = tt.el
                    if (text.isNotBlank()) {
                        if (e == null) ink.add(TextEl(Ids.next(), text, tt.x, tt.y, fs, ts.color)) else ink.replace(e.copy(text = text))
                    }
                    textTarget = null
                }) { Text("Save text") }
            },
            dismissButton = {
                Row {
                    if (tt.el != null) TextButton(onClick = { ink.remove(tt.el.id); textTarget = null }) { Text("Delete") }
                    TextButton(onClick = { textTarget = null }) { Text("Cancel") }
                }
            }
        )
    }
}

@Composable
fun Toolbar(ink: PageInk, ts: ToolState, onImage: () -> Unit) {
    Surface(tonalElevation = 3.dp) {
        Column {
            if (ts.tool == 's') {
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf('l' to "Line", 'a' to "Arrow", 'r' to "Rectangle", 'o' to "Oval").forEach { (k, label) ->
                        FilterChip(selected = ts.shape == k, onClick = { ts.shape = k }, label = { Text(label) })
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf('p' to "Pen", 'h' to "Highlighter", 'e' to "Eraser", 'l' to "Lasso", 's' to "Shapes", 't' to "Text").forEach { (t, label) ->
                    FilterChip(selected = ts.tool == t, onClick = {
                        ts.tool = t
                        if (t == 'h' && ts.color == INKS[0].second) ts.color = INKS[4].second
                    }, label = { Text(label) })
                }
                TextButton(onClick = onImage) { Text("Image") }
                Spacer(Modifier.width(4.dp))
                INKS.forEach { (name, c) ->
                    Box(
                        Modifier.size(48.dp).clickable(onClickLabel = "$name ink") {
                            ts.color = c
                            if (ts.tool == 'e' || ts.tool == 'l') ts.tool = 'p'
                        },
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            Modifier.size(28.dp).clip(CircleShape).background(Color(c))
                                .border(if (ts.color == c) 3.dp else 1.dp, if (ts.color == c) MaterialTheme.colorScheme.primary else Color.Gray, CircleShape)
                        )
                    }
                }
                Spacer(Modifier.width(4.dp))
                listOf(2f to "Thin", 3f to "Medium", 7f to "Thick").forEach { (z, label) ->
                    FilterChip(selected = ts.size == z, onClick = { ts.size = z }, label = { Text(label) })
                }
                TextButton(enabled = ink.undo.isNotEmpty(), onClick = { ink.doUndo() }) { Text("Undo") }
                TextButton(enabled = ink.redo.isNotEmpty(), onClick = { ink.doRedo() }) { Text("Redo") }
                FilterChip(selected = ts.penOnly, onClick = { ts.penOnly = !ts.penOnly }, label = { Text("Pen only") })
            }
        }
    }
}

suspend fun AwaitPointerEventScope.navLoop(v: ViewState) {
    while (true) {
        val ev = awaitPointerEvent()
        if (ev.changes.none { it.pressed }) break
        val z = ev.calculateZoom()
        val pan = ev.calculatePan()
        val c = ev.calculateCentroid()
        if (c.isSpecified) {
            val nz = (v.z * z).coerceIn(0.4f, 8f)
            val f = nz / v.z
            v.ox = (v.ox - c.x) * f + c.x + pan.x
            v.oy = (v.oy - c.y) * f + c.y + pan.y
            v.z = nz
        }
        ev.changes.forEach { it.consume() }
    }
}

@Composable
fun PageCanvas(
    nb: Notebook, page: PageData, ink: PageInk, pdf: ImageBitmap?, ts: ToolState, view: ViewState,
    onTextTap: (Offset) -> Unit
) {
    val inkS = rememberUpdatedState(ink)
    val tapS = rememberUpdatedState(onTextTap)
    val primary = MaterialTheme.colorScheme.primary
    val bg = MaterialTheme.colorScheme.surfaceVariant
    Canvas(
        Modifier.fillMaxSize().clipToBounds().background(bg).pointerInput(Unit) {
            awaitEachGesture {
                val k = inkS.value
                val down = awaitFirstDown(requireUnconsumed = false)
                val sc0 = (size.width - 24f) / PW
                fun pg(o: Offset) = Offset((o.x - view.ox) / view.z / sc0, (o.y - view.oy) / view.z / sc0)
                fun pr(c: PointerInputChange) = if (c.pressure > 0f) c.pressure else 0.5f
                val finger = down.type == PointerType.Touch
                val tool = ts.tool
                val strokeTool = if (tool == 'h') 'h' else 'p'
                val mode = when {
                    ts.penOnly && finger -> 0
                    down.type == PointerType.Eraser || tool == 'e' -> 1
                    tool == 'l' -> 2
                    tool == 's' -> 3
                    tool == 't' -> 4
                    else -> 5
                }
                down.consume()
                if (mode == 0) { navLoop(view); return@awaitEachGesture }
                val start = pg(down.position)
                var last = start
                var end = start
                val pts = ArrayList<Pt>()
                val poly = ArrayList<Offset>()
                var moving = false
                var switched = false
                when (mode) {
                    1 -> { k.beginErase(); k.erase(start.x, start.y) }
                    2 -> {
                        val b = k.selBounds()
                        if (b != null && b.inflate(12f).contains(start)) { moving = true; k.beginMove() }
                        else { k.sel = emptySet(); poly.add(start) }
                    }
                    3 -> k.live = ShapeEl(0L, ts.shape, ts.color, ts.size, start.x, start.y, start.x, start.y)
                    5 -> {
                        pts.add(Pt(start.x, start.y, pr(down)))
                        k.live = StrokeEl(0L, strokeTool, ts.color, ts.size, pts.toList())
                    }
                }
                while (true) {
                    val ev = awaitPointerEvent()
                    if (finger && ev.changes.count { it.pressed } > 1) { switched = true; break }
                    val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                    if (!ch.pressed) break
                    val p = pg(ch.position)
                    end = p
                    when (mode) {
                        1 -> k.erase(p.x, p.y)
                        2 -> if (moving) { k.moveSel(p.x - last.x, p.y - last.y); last = p } else { poly.add(p); k.lasso = poly.toList() }
                        3 -> k.live = ShapeEl(0L, ts.shape, ts.color, ts.size, start.x, start.y, p.x, p.y)
                        5 -> {
                            ch.historical.forEach { h -> val q = pg(h.position); pts.add(Pt(q.x, q.y, pr(ch))) }
                            pts.add(Pt(p.x, p.y, pr(ch)))
                            k.live = StrokeEl(0L, strokeTool, ts.color, ts.size, pts.toList())
                        }
                    }
                    ch.consume()
                }
                if (switched) {
                    k.live = null; k.lasso = emptyList()
                    navLoop(view)
                    return@awaitEachGesture
                }
                when (mode) {
                    2 -> if (!moving) { k.selectIn(poly); k.lasso = emptyList() }
                    3 -> {
                        if (kotlin.math.hypot(end.x - start.x, end.y - start.y) > 4f) {
                            k.add(ShapeEl(Ids.next(), ts.shape, ts.color, ts.size, start.x, start.y, end.x, end.y))
                        }
                        k.live = null
                    }
                    4 -> tapS.value(start)
                    5 -> {
                        if (pts.isNotEmpty()) k.add(StrokeEl(Ids.next(), strokeTool, ts.color, ts.size, pts.toList()))
                        k.live = null
                    }
                }
            }
        }
    ) {
        view.cw = size.width
        view.chh = size.height
        val sc0 = (size.width - 24f) / PW
        val paper = page.paperOf(nb)
        withTransform({
            translate(view.ox, view.oy)
            scale(view.z, view.z, Offset.Zero)
        }) {
            if (paper == "infinite") {
                val vis = Rect(
                    -view.ox / view.z / sc0, -view.oy / view.z / sc0,
                    (size.width - view.ox) / view.z / sc0, (size.height - view.oy) / view.z / sc0
                )
                drawRect(Color.White, Offset(vis.left * sc0, vis.top * sc0), Size(vis.width * sc0, vis.height * sc0))
                drawInfiniteDots(vis, sc0)
                drawElements(ink.els, sc0)
            } else {
                drawPageBase(paper, pdf, page.h, sc0)
                clipRect(0f, 0f, PW * sc0, page.h * sc0) { drawElements(ink.els, sc0) }
            }
            ink.live?.let { drawEl(it, sc0) }
            if (ink.lasso.size > 1) {
                val path = Path()
                path.moveTo(ink.lasso[0].x * sc0, ink.lasso[0].y * sc0)
                ink.lasso.drop(1).forEach { path.lineTo(it.x * sc0, it.y * sc0) }
                drawPath(path, primary, style = Stroke(2f / view.z, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))))
            }
            ink.selBounds()?.let {
                drawRect(
                    primary, Offset(it.left * sc0 - 6f, it.top * sc0 - 6f), Size(it.width * sc0 + 12f, it.height * sc0 + 12f),
                    style = Stroke(2f / view.z, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f)))
                )
            }
        }
    }
}

@Composable
fun PageThumb(nb: Notebook, pg: PageData) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, pg.pdfPage) {
        value = if (pg.pdfPage >= 0) PdfCache.get(ctx, nb.pdf, pg.pdfPage, 360) else null
    }
    Canvas(Modifier.fillMaxWidth().aspectRatio(PW / pg.h)) {
        val sc = size.width / PW
        drawPageBase(pg.paperOf(nb), bmp, pg.h, sc)
        clipRect(0f, 0f, size.width, size.height) { drawElements(pg.els, sc) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PagesScreen(nb: Notebook, current: Int, ver: Int, onPick: (Int) -> Unit, onChange: (Int) -> Unit, onBack: () -> Unit) {
    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Pages") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to page") } }
        )
    }) { pad ->
        key(ver) {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(130.dp),
                modifier = Modifier.padding(pad).fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                itemsIndexed(nb.pages) { i, pg ->
                    Column {
                        Box(
                            Modifier.border(if (i == current) 3.dp else 1.dp, if (i == current) MaterialTheme.colorScheme.primary else Color.Gray, RoundedCornerShape(4.dp))
                                .clickable(onClickLabel = "Open page ${i + 1}") { onPick(i) }
                        ) { PageThumb(nb, pg) }
                        Text("Page ${i + 1}", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
                        val pad8 = PaddingValues(horizontal = 8.dp)
                        Row {
                            TextButton(enabled = i > 0, contentPadding = pad8, onClick = {
                                nb.pages.add(i - 1, nb.pages.removeAt(i)); onChange(if (current == i) i - 1 else current)
                            }) { Text("◀") }
                            TextButton(enabled = i < nb.pages.size - 1, contentPadding = pad8, onClick = {
                                nb.pages.add(i + 1, nb.pages.removeAt(i)); onChange(if (current == i) i + 1 else current)
                            }) { Text("▶") }
                        }
                        Row {
                            TextButton(contentPadding = pad8, onClick = {
                                nb.pages.add(i + 1, PageData(pg.els, pg.paper, pg.h, pg.pdfPage)); onChange(i + 1)
                            }) { Text("Copy") }
                            TextButton(enabled = nb.pages.size > 1, contentPadding = pad8, onClick = {
                                nb.pages.removeAt(i)
                                onChange(if (i < current) current - 1 else min(current, nb.pages.size - 1))
                            }) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }
}
