package com.example.mynotes

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Canvas
import androidx.compose.ui.graphics.drawscope.CanvasDrawScope
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

fun displayName(ctx: Context, uri: Uri): String = try {
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        if (c.moveToFirst()) {
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0) c.getString(i).removeSuffix(".pdf") else null
        } else null
    } ?: "Imported PDF"
} catch (e: Exception) {
    "Imported PDF"
}

suspend fun importPdf(ctx: Context, uri: Uri, name: String): Notebook? = withContext(Dispatchers.IO) {
    try {
        val id = "n${System.currentTimeMillis()}"
        val dir = File(ctx.filesDir, "pdfs")
        dir.mkdirs()
        val f = File(dir, "$id.pdf")
        ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { i.copyTo(it) } } ?: return@withContext null
        val pages = mutableListOf<PageData>()
        PdfRenderer(ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)).use { r ->
            for (i in 0 until r.pageCount) {
                r.openPage(i).use { p -> pages.add(PageData(h = PW * p.height / p.width, pdfPage = i)) }
            }
        }
        if (pages.isEmpty()) null
        else Notebook(id, name, COVERS[4], "blank", pages, System.currentTimeMillis(), pdf = "$id.pdf")
    } catch (e: Exception) {
        null
    }
}

suspend fun importImage(ctx: Context, uri: Uri): Pair<String, Float>? = withContext(Dispatchers.IO) {
    try {
        val dir = File(ctx.filesDir, "images")
        dir.mkdirs()
        val name = "img${System.nanoTime()}.jpg"
        val f = File(dir, name)
        ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { i.copyTo(it) } } ?: return@withContext null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        if (o.outWidth <= 0) { f.delete(); null } else Pair(name, o.outHeight.toFloat() / o.outWidth)
    } catch (e: Exception) {
        null
    }
}

suspend fun exportPdf(ctx: Context, nb: Notebook, out: Uri) = withContext(Dispatchers.IO) {
    val doc = PdfDocument()
    try {
        nb.pages.forEachIndexed { i, pg ->
            val w = 595
            val h = (595 * pg.h / PW).toInt().coerceAtLeast(100)
            val page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, i + 1).create())
            val sc = w / PW
            val bg = if (pg.pdfPage >= 0) PdfCache.get(ctx, nb.pdf, pg.pdfPage, 1600) else null
            CanvasDrawScope().draw(Density(1f), LayoutDirection.Ltr, Canvas(page.canvas), Size(w.toFloat(), h.toFloat())) {
                drawPageBase(pg.paperOf(nb), bg, pg.h, sc)
                drawElements(pg.els, sc)
            }
            doc.finishPage(page)
        }
        ctx.contentResolver.openOutputStream(out)?.use { doc.writeTo(it) }
    } catch (e: Exception) {
    } finally {
        doc.close()
    }
}

suspend fun backup(ctx: Context, books: List<Notebook>, folders: List<String>, out: Uri) = withContext(Dispatchers.IO) {
    try {
        ctx.contentResolver.openOutputStream(out)?.use { os ->
            ZipOutputStream(os).use { z ->
                z.putNextEntry(ZipEntry("library.json"))
                z.write(Store.encode(books, folders).toByteArray())
                z.closeEntry()
                for (dir in listOf("images", "pdfs")) {
                    File(ctx.filesDir, dir).listFiles()?.forEach { f ->
                        z.putNextEntry(ZipEntry("$dir/${f.name}"))
                        f.inputStream().use { it.copyTo(z) }
                        z.closeEntry()
                    }
                }
            }
        }
    } catch (e: Exception) {
    }
}

suspend fun restore(ctx: Context, input: Uri): LibData? = withContext(Dispatchers.IO) {
    try {
        var json: String? = null
        ctx.contentResolver.openInputStream(input)?.use { ins ->
            ZipInputStream(ins).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val name = e.name
                    if (name == "library.json") {
                        json = z.readBytes().toString(Charsets.UTF_8)
                    } else if (name.startsWith("images/") || name.startsWith("pdfs/")) {
                        val f = File(ctx.filesDir, name)
                        if (f.canonicalPath.startsWith(ctx.filesDir.canonicalPath)) {
                            f.parentFile?.mkdirs()
                            f.outputStream().use { z.copyTo(it) }
                        }
                    }
                    z.closeEntry()
                    e = z.nextEntry
                }
            }
        }
        json?.let { Store.decode(it) }
    } catch (e: Exception) {
        null
    }
}
